## Description
This Flask-based API allows for uploading files (images, PDFs, videos, etc.).

## Requirements
- Python 3.12.3
- Flask 3.0.3
- Werkzeug 3.0.3

## Installation
1. Clone the repository or download the code.
2. Install the required packages:
    pip install virtualenv
    pip3 install flask_wtf wtforms
    pip install Flask 

## Running the Application
1. Run the Flask app: flask run
